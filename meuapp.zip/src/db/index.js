import * as SQLite from 'expo-sqlite';
import { Platform } from 'react-native';

// On web, expo-sqlite uses an in-memory/websql-like shim isn't available; provide guard
const db = Platform.OS === 'web' ? null : SQLite.openDatabase('eldercare.db');

export function initDatabase() {
  return new Promise((resolve, reject) => {
  if (!db) { resolve(); return; }
  db.transaction(tx => {
      // users table
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          cpf TEXT UNIQUE,
          email TEXT,
          password_hash TEXT NOT NULL,
          role TEXT CHECK(role IN ('family','caregiver')),
          subrole TEXT CHECK(subrole IN ('formal','informal')),
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );`
      );

      // elders table
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS elders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          full_name TEXT NOT NULL,
          age INTEGER,
          address TEXT,
          medical_conditions TEXT,
          allergies TEXT,
          notes TEXT,
          responsible_family_id INTEGER,
          FOREIGN KEY (responsible_family_id) REFERENCES users(id)
        );`
      );

      // medication_reminders
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS medication_reminders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          elder_id INTEGER,
          name TEXT NOT NULL,
          time TEXT NOT NULL,
          FOREIGN KEY (elder_id) REFERENCES elders(id)
        );`
      );

      // caregiver_links
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS caregiver_links (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          elder_id INTEGER,
          caregiver_id INTEGER,
          FOREIGN KEY (elder_id) REFERENCES elders(id),
          FOREIGN KEY (caregiver_id) REFERENCES users(id)
        );`
      );

      // link_codes
      tx.executeSql(
        `CREATE TABLE IF NOT EXISTS link_codes (
          code TEXT PRIMARY KEY,
          elder_id INTEGER,
          created_by INTEGER,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (elder_id) REFERENCES elders(id),
          FOREIGN KEY (created_by) REFERENCES users(id)
        );`
      );
    }, reject, resolve);
  });
}

export function query(sql, params = []) {
  return new Promise((resolve, reject) => {
  if (!db) { reject(new Error('DB indisponível no Web')); return; }
  db.readTransaction(tx => {
      tx.executeSql(sql, params, (_, result) => resolve(result), (_, err) => {
        reject(err);
        return true;
      });
    });
  });
}

export function execute(sql, params = []) {
  return new Promise((resolve, reject) => {
  if (!db) { reject(new Error('DB indisponível no Web')); return; }
  db.transaction(tx => {
      tx.executeSql(sql, params, (_, result) => resolve(result), (_, err) => {
        reject(err);
        return true;
      });
    });
  });
}
